Arduino-PowerSocketControlWeb
=============================
Arduino Power Socket Control (Web Server) for home automation

http://jfrmilner.wordpress.com/2013/03/31/arduino-power-socket-control-web-server-for-home-automation/